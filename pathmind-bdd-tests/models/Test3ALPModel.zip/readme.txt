How to run the exported model.

Please run the executable file (<modelname>_windows.bat for Windows or <modelname>_mac for Mac and <modelname>_linux.sh for Linux) located in the same folder.

Mac and Linux users: if the model doesn't run (this may happen if the model was exported on a Windows machine), make the file executable by calling:
chmod +x <modelname>_linux.sh
chmod +x <modelname>_mac
